angular.module('app.controllers', [])
  
.controller('signupCtrl', function($scope) {

})
   
.controller('registerCtrl', function($scope) {

})
   
.controller('mapPageCtrl', function($scope) {

})
   
.controller('groupPageCtrl', function($scope) {

})
      
.controller('settingsCtrl', function($scope) {

})
   
.controller('contactDetailCtrl', function($scope) {

})
 